package com.khalayti.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.khalayti.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import android.graphics.Bitmap

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val migration1to2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL("ALTER TABLE hives ADD COLUMN parentHiveId INTEGER")
                database.execSQL("CREATE TABLE IF NOT EXISTS package_records (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, parentHiveId INTEGER NOT NULL, childHiveId INTEGER NOT NULL, date TEXT NOT NULL, note TEXT NOT NULL)")
            }
        }
        val db = Room.databaseBuilder(applicationContext, KhalaytiDatabase::class.java, "khalayti.db")
            .addMigrations(migration1to2).build()
        setContent { KhalaytiApp(db.dao()) }
    }
}

private val quickNotes = listOf("وجود ملكة", "وجود بيض جديد", "تحتاج تغذية", "هادئة", "شرسة", "فحص فاروا", "وجود حضنة", "لا توجد ملكة")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KhalaytiApp(dao: ApiaryDao) {
    val hives by dao.observeHives().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf<Hive?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var showEconomy by remember { mutableStateOf(false) }
    var scanMessage by remember { mutableStateOf<String?>(null) }

    val scanner = rememberLauncherForActivityResult(ScanContract()) { result ->
        val scanned = result.contents
        if (scanned != null) {
            val code = scanned.removePrefix("KHALAYTI:").trim()
            scope.launch {
                val found = dao.findHiveByCode(code)
                if (found != null) {
                    selected = found
                    scanMessage = null
                } else {
                    scanMessage = "لم يتم العثور على خلية بالرمز: $code"
                }
            }
        }
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF9A641A))) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if (selected == null) "🐝 خليتي – إدارة المنحل" else "الخلية ${selected!!.code}") },
                    navigationIcon = { if (selected != null) IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, "رجوع") } },
                    actions = { TextButton(onClick = { showEconomy = true }) { Text("الحسابات") } }
                )
            },
            floatingActionButton = {
                if (selected == null && hives.size < 500) FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "إضافة خلية") }
            }
        ) { padding ->
            if (selected == null) {
                Column(Modifier.padding(padding).padding(16.dp)) {
                    Text("منحل واحد • السعة القصوى 500 خلية", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("الخلايا المسجلة: ${hives.size} / 500")
                    LinearProgressIndicator(progress = { hives.size / 500f }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = {
                            scanner.launch(
                                ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                                    .setPrompt("وجّه الكاميرا نحو رمز QR الموجود على صندوق الخلية")
                                    .setBeepEnabled(false).setOrientationLocked(true)
                            )
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("مسح رمز QR لفتح سجل الخلية") }
                    scanMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    Spacer(Modifier.height(12.dp))
                    if (hives.size >= 500) Text("وصلت إلى الحد الأقصى المحدد لهذا المنحل.")
                    if (hives.isEmpty()) {
                        Text("لم تتم إضافة خلايا بعد. اضغط + لإضافة أول خلية.")
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(hives, key = { it.id }) { hive ->
                                Card(onClick = { selected = hive }, modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(16.dp)) {
                                        Text("🐝 ${hive.code}", style = MaterialTheme.typography.titleMedium)
                                        Text("القوة: ${hive.strength} • الإطارات المغطاة: ${hive.coveredFrames}")
                                        Text("الطرود المنتجة: ${hive.packagesProduced}")
                                        Text("افتح البطاقة لعرض رمز QR الخاص بهذه الخلية")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                HiveDetails(hive = selected!!, dao = dao, onUpdate = { selected = it })
            }
        }
    }

    if (showAdd) AddHiveDialog(
        onDismiss = { showAdd = false },
        onSave = { code, queenDate, queenType, strength, frames, brood ->
            scope.launch {
                if (dao.findHiveByCode(code) == null) {
                    dao.addHive(Hive(code = code, queenDate = queenDate, queenType = queenType,
                        strength = strength, coveredFrames = frames, broodAmount = brood))
                } else {
                    scanMessage = "رقم الخلية مستخدم مسبقاً. اختر رقماً آخر."
                }
            }
            showAdd = false
        }
    )
    if (showEconomy) {
        AlertDialog(onDismissRequest = { showEconomy = false }, title = { Text("الإنتاج والحسابات") },
            text = { Text("تجهيز جداول الإنتاج والمصروفات في قاعدة البيانات بدأ. ستُفعّل شاشة التسجيل والتقارير المالية في مرحلة لاحقة.") },
            confirmButton = { TextButton(onClick = { showEconomy = false }) { Text("حسناً") } })
    }
}

@Composable
private fun AddHiveDialog(onDismiss: () -> Unit, onSave: (String,String,String,String,Int,String) -> Unit) {
    var code by remember { mutableStateOf("KH-${System.currentTimeMillis().toString().takeLast(5)}") }
    var queenDate by remember { mutableStateOf("") }
    var queenType by remember { mutableStateOf("") }
    var strength by remember { mutableStateOf("متوسطة") }
    var frames by remember { mutableStateOf("5") }
    var brood by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة خلية جديدة") },
        text = {
            Column(Modifier.heightIn(max = 480.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(code, { code = it }, label = { Text("رقم الخلية") }, singleLine = true)
                OutlinedTextField(queenDate, { queenDate = it }, label = { Text("تاريخ وضع الملكة") }, placeholder = { Text("مثال: 2026-04-15") })
                OutlinedTextField(queenType, { queenType = it }, label = { Text("نوع / سلالة الملكة") })
                Text("قوة الطائفة")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("ضعيفة", "متوسطة", "قوية").forEach { value ->
                        FilterChip(selected = strength == value, onClick = { strength = value }, label = { Text(value) })
                    }
                }
                OutlinedTextField(frames, { frames = it.filter(Char::isDigit) }, label = { Text("عدد الإطارات المغطاة بالنحل") })
                OutlinedTextField(brood, { brood = it }, label = { Text("كمية / مساحة الحضنة") })
            }
        },
        confirmButton = { TextButton(onClick = { if (code.isNotBlank()) onSave(code.trim(), queenDate, queenType, strength, frames.toIntOrNull() ?: 0, brood) }) { Text("حفظ") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}

@Composable
private fun HiveDetails(hive: Hive, dao: ApiaryDao, onUpdate: (Hive) -> Unit) {
    val scope = rememberCoroutineScope()
    val inspections by dao.observeInspections(hive.id).collectAsState(initial = emptyList())
    val children by dao.observeChildren(hive.id).collectAsState(initial = emptyList())
    val packageRecords by dao.observePackageRecords(hive.id).collectAsState(initial = emptyList())
    var showAddOffspring by remember { mutableStateOf(false) }
    var selectedNotes by remember { mutableStateOf(setOf<String>()) }
    var extra by remember { mutableStateOf("") }
    var packages by remember { mutableStateOf(hive.packagesProduced.toString()) }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val qrBitmap = remember(hive.code) { createQrBitmap("KHALAYTI:${hive.code}") }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("بطاقة تعريف الخلية", style = MaterialTheme.typography.titleLarge)
        Text("المعرف: ${hive.code}")
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Image(bitmap = qrBitmap.asImageBitmap(), contentDescription = "رمز QR للخلية ${hive.code}", modifier = Modifier.size(190.dp))
        }
        Text("اطبع هذا الرمز والصقه على صندوق الخلية. عند مسحه من داخل التطبيق يفتح سجلها مباشرة.", style = MaterialTheme.typography.bodySmall)
        Divider()
        Text("الملكة: ${hive.queenType.ifBlank { "غير محدد" }} • تاريخها: ${hive.queenDate.ifBlank { "غير محدد" }}")
        Text("القوة: ${hive.strength} • الإطارات المغطاة: ${hive.coveredFrames}")
        Text("الحضنة: ${hive.broodAmount.ifBlank { "غير محدد" }}")
        Divider()
        Text("عدد الطرود التي أُخرجت من هذه الخلية", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(packages, { packages = it.filter(Char::isDigit) }, label = { Text("إجمالي الطرود") })
        Button(onClick = {
            val updated = hive.copy(packagesProduced = packages.toIntOrNull() ?: 0)
            scope.launch { dao.updateHive(updated) }
            onUpdate(updated)
        }) { Text("حفظ عدد الطرود") }
        Divider()
        Text("الطرود والخلايا الناتجة من هذه الخلية", style = MaterialTheme.typography.titleMedium)
        Text("عدد الخلايا الابنة المسجلة: ${children.size}")
        Button(onClick = { showAddOffspring = true }, modifier = Modifier.fillMaxWidth()) {
            Text("تسجيل طرد جديد كخلية ابنة")
        }
        if (children.isEmpty()) {
            Text("لم يتم تسجيل خلايا ابنة بعد.", style = MaterialTheme.typography.bodySmall)
        } else {
            children.forEach { child ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🐝 ${child.code}", style = MaterialTheme.typography.titleSmall)
                        Text("خلية ابنة للخلية ${hive.code}")
                        Text("تاريخ إنشاء الطرد: ${packageRecords.firstOrNull { it.childHiveId == child.id }?.date ?: "غير مسجل"}")
                    }
                }
            }
        }
        Divider()
        Text("فحص سريع", style = MaterialTheme.typography.titleMedium)
        Text("اختر الملاحظات بنقرة واحدة:")
        quickNotes.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { note ->
                    FilterChip(selected = note in selectedNotes, onClick = {
                        selectedNotes = if (note in selectedNotes) selectedNotes - note else selectedNotes + note
                    }, label = { Text(note) })
                }
            }
        }
        OutlinedTextField(extra, { extra = it }, label = { Text("ملاحظة إضافية (اختياري)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            val text = (selectedNotes.toList() + listOf(extra).filter { it.isNotBlank() }).joinToString("، ")
            if (text.isNotBlank()) {
                scope.launch { dao.addInspection(Inspection(hiveId = hive.id, date = today, observations = text)) }
                selectedNotes = emptySet(); extra = ""
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("حفظ الفحص") }
        Text("سجل الفحوصات", style = MaterialTheme.typography.titleMedium)
        if (inspections.isEmpty()) Text("لا توجد فحوصات مسجلة.")
        inspections.forEach { Text("• ${it.date}: ${it.observations}") }
    }
    if (showAddOffspring) {
        AddOffspringDialog(
            parent = hive,
            onDismiss = { showAddOffspring = false },
            onSave = { childCode, date, queenType, note ->
                scope.launch {
                    if (dao.findHiveByCode(childCode) == null) {
                        val childId = dao.addHive(
                            Hive(
                                code = childCode,
                                queenDate = date,
                                queenType = queenType,
                                strength = "ضعيفة",
                                coveredFrames = 0,
                                broodAmount = "",
                                parentHiveId = hive.id
                            )
                        )
                        dao.addPackageRecord(
                            PackageRecord(
                                parentHiveId = hive.id,
                                childHiveId = childId,
                                date = date,
                                note = note
                            )
                        )
                        val updatedParent = hive.copy(packagesProduced = hive.packagesProduced + 1)
                        dao.updateHive(updatedParent)
                        onUpdate(updatedParent)
                    }
                }
                showAddOffspring = false
            }
        )
    }
}

@Composable
private fun AddOffspringDialog(
    parent: Hive,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var code by remember { mutableStateOf("KH-${System.currentTimeMillis().toString().takeLast(5)}") }
    var date by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())) }
    var queenType by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تسجيل طرد جديد من ${parent.code}") },
        text = {
            Column(
                Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("سيُنشأ سجل خلية مستقل مرتبط بالخلية الأم.")
                OutlinedTextField(code, { code = it }, label = { Text("رقم الخلية الابنة") }, singleLine = true)
                OutlinedTextField(date, { date = it }, label = { Text("تاريخ إخراج الطرد") })
                OutlinedTextField(queenType, { queenType = it }, label = { Text("نوع / حالة الملكة (اختياري)") })
                OutlinedTextField(note, { note = it }, label = { Text("ملاحظات الطرد (اختياري)") })
            }
        },
        confirmButton = {
            TextButton(onClick = { if (code.isNotBlank()) onSave(code.trim(), date, queenType, note) }) { Text("إنشاء الخلية الابنة") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

private fun createQrBitmap(content: String): Bitmap {
    val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, 600, 600)
    val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.RGB_565)
    for (x in 0 until 600) {
        for (y in 0 until 600) {
            bitmap.setPixel(x, y, if (matrix[x, y]) android.graphics.Color.BLACK else android.graphics.Color.WHITE)
        }
    }
    return bitmap
}
