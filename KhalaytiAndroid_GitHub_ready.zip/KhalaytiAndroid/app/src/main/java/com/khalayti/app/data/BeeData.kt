package com.khalayti.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "hives")
data class Hive(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val queenDate: String = "",
    val queenType: String = "",
    val strength: String = "متوسطة",
    val coveredFrames: Int = 0,
    val broodAmount: String = "",
    val packagesProduced: Int = 0,
    val notes: String = "",
    val parentHiveId: Long? = null
)

@Entity(tableName = "inspections")
data class Inspection(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hiveId: Long,
    val date: String,
    val observations: String,
    val voiceText: String = ""
)

@Entity(tableName = "harvests")
data class Harvest(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val hiveId: Long,
    val date: String,
    val kilograms: Double,
    val salePricePerKg: Double = 0.0
)

@Entity(tableName = "package_records")
data class PackageRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val parentHiveId: Long,
    val childHiveId: Long,
    val date: String,
    val note: String = ""
)

@Entity(tableName = "expenses")
data class Expense(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val category: String,
    val amount: Double,
    val description: String = ""
)

@Dao
interface ApiaryDao {
    @Query("SELECT * FROM hives ORDER BY code")
    fun observeHives(): Flow<List<Hive>>

    @Query("SELECT * FROM hives WHERE code = :code LIMIT 1")
    suspend fun findHiveByCode(code: String): Hive?

    @Insert
    suspend fun addHive(hive: Hive): Long

    @Update
    suspend fun updateHive(hive: Hive)

    @Delete
    suspend fun deleteHive(hive: Hive)

    @Query("SELECT * FROM inspections WHERE hiveId = :hiveId ORDER BY id DESC")
    fun observeInspections(hiveId: Long): Flow<List<Inspection>>

    @Query("SELECT * FROM hives WHERE parentHiveId = :parentId ORDER BY id DESC")
    fun observeChildren(parentId: Long): Flow<List<Hive>>

    @Query("SELECT * FROM package_records WHERE parentHiveId = :parentId ORDER BY id DESC")
    fun observePackageRecords(parentId: Long): Flow<List<PackageRecord>>

    @Insert
    suspend fun addPackageRecord(record: PackageRecord)

    @Insert
    suspend fun addInspection(inspection: Inspection)

    @Insert
    suspend fun addHarvest(harvest: Harvest)

    @Query("SELECT COALESCE(SUM(kilograms), 0) FROM harvests")
    fun totalHoneyKg(): Flow<Double>

    @Query("SELECT COALESCE(SUM(amount), 0) FROM expenses")
    fun totalExpenses(): Flow<Double>

    @Insert
    suspend fun addExpense(expense: Expense)
}

@Database(entities = [Hive::class, Inspection::class, Harvest::class, Expense::class, PackageRecord::class], version = 2)
abstract class KhalaytiDatabase : RoomDatabase() {
    abstract fun dao(): ApiaryDao
}
